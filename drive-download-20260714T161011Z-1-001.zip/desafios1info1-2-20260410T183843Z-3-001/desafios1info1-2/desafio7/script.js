let n1= parseFloat (prompt("Insira sua primeira nota"));
let n2= parseFloat (prompt("Insira sua segunda nota"));
let n3= parseFloat (prompt("Insira sua terceira nota"));
let p1= 2;
let p2= 3;
let p3= 5;
let media= ((n1*p1)+(n2*p2)+(n3*p3))/10;
alert (`A média da suas notas é de ${media}`);