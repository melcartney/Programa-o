let quantdol= parseFloat (prompt("Quantos dólares você possui no cofre?"));
let cotdol= parseFloat (prompt("Qual a cotação do dólar hoje?"));
let valorreal= quantdol*cotdol;
alert (`O valor da sua quantidade de dólares em reais é R$ ${valorreal} \n
    sendo sua quantidade de dólares $ ${quantdol}`);