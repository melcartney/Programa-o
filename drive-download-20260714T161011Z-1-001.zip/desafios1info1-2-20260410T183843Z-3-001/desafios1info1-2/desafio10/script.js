let peso= Number(prompt("Insira seu peso atual em Kg"));
let porcgor= ((peso*15)/100);
let pesogord= porcgor+peso;
let porcma= ((peso*20)/100);
let pesoma= peso-porcma;
alert (`Caso você engorde 15%, você pesará ${pesogord .toFixed(3)}Kg \n
E caso você emagreça 20% você pesará ${pesoma .toFixed(3)}Kg`);