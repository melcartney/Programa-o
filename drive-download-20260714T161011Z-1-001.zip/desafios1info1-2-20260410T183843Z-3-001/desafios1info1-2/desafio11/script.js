let Gado= Number (prompt("Quantas cabeças de gado há?"));
let her= Number (prompt("Qual o número de herdeiros?"));
let doa= ((Gado*15)/100)
let divs= (Gado-doa)/her
alert (`Sabendo que o pai doou 15% do seu gado, o total para os herdeiros foi de ${divs} para cada \n
    , na divisão, sobrou ${Gado%her} cabeças de gado`);

