console.log("O pedreiro cobra R$20 a hora")
let horaPed= parseFloat (prompt("Por quantas horas o pedreiro trabalhou?"));
console.log(`O pedreiro trabalhou por ${horaPed}horas`);
console.log("O pintor cobra R$16 a hora");
let horaPin= parseFloat (prompt("Por quantas horas o pintor trabalhou?"));
console.log(`O pintor trabalhou por ${horaPin}`);
let valorPed= horaPed*20;
let valorPin= horaPin*16;
alert(`O valor total do serviço é R$ ${valorPed+valorPin}`)