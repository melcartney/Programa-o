let Preus= Number (prompt("Insira o preço do produto"));
const desc= 5
let valdsc= (Preus*desc)/100
let valto= Preus-valdsc
alert (`Com um desconto de 5%, o valor total do produto passa a ser R$${valto .toFixed(2)} \n
E o valor do desconto foi de R$${valdsc .toFixed(2)}`);