let prcP= Number (prompt ("Insira o preço do produto original"));
let prcPD= Number (prompt ("Insira o valor do produto com desconto"));
let valorDsc= ((prcP-prcPD)/prcP)*100;
alert (`A porcentagem do desconto foi de ${valorDsc .toFixed(2)}%`);