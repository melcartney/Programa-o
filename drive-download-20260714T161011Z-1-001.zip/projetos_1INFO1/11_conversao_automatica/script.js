console.log("123"+4);
console.log(typeof("123"+4));
console.log("30"-20);
console.log(typeof("30"-20));
console.log("xuxa"*3);
console.log(typeof("xuxa"*3));