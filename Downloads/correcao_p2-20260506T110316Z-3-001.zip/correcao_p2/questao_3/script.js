let largura= parseFloat(prompt('Qual a largura do piso? (em m)'));
let comprimento= parseFloat(prompt('Qual a comprimento do piso? (em m)'));
let areaPeca= parseFloat(prompt('Qual a area de cobertura de cada peça?(em m2)'));
let perda= parseFloat(prompt('Qual é o percentual de perda?'));
let preco= parseFloat(prompt('Qual é o preço de cada peça? (em R$)'));

let areaPiso= largura*comprimento
let finalAreaPiso= areaPiso*(perda/100)
let fianlPiso= areaPiso-finalAreaPiso
let pecasNecessarias= areaPeca/finalAreaPiso
let valorTotal= pecasNecessarias*preco

alert('A area do piso em m2 é: ' + areaPiso);
alert('A area com a perda sera: ' + fianlPiso);
alert('O total de peças necessarias sera: ' + Math.ceil(pecasNecessarias));
alert('O custo final das peças sera: R$' + valorTotal);
