let aulas= parseFloat(prompt('Quantas aulas você da por dia?'));
let duracao= parseFloat(prompt('Qual a duração de cada aula?(em min)'));
let dias=parseFloat(prompt('Qual o total de dias trabalhados?'));

let minDia= aulas*duracao
let minTotal= minDia*dias
let hTrabalhados= minTotal/60

alert('O total de minutos trabalhados são: ' + minTotal);
alert('O total de horas trabalhadas foram: ' + hTrabalhados);