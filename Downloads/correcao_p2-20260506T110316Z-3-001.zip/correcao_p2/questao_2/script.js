let valorCompra= parseFloat(prompt('Qual foi o valor total da compra? (em R$)'));
let parcelas= parseFloat(prompt('Em quantas parcelas foram feitas?'));
let juros= parseFloat(prompt('Qual é a taxa de acrescimo de cada parcela? (em %)'));

let valorJuros = valorCompra*(juros/100)
let valorparcela= (valorCompra+valorJuros)/parcelas
let valorFinal = valorparcela*parcelas

alert('O valor total da compra foi de: R$' + valorFinal);
alert('O valor de cada parcela é de: R$' + valorparcela);
alert('O valor da taxa percentual é de: R$' + valorJuros);